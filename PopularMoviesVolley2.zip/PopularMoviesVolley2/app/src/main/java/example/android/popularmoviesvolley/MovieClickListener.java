package example.android.popularmoviesvolley;

public interface MovieClickListener {
    void onMovieClicked(int position);
}
