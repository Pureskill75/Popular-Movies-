package example.android.popularmoviesvolley;

public interface TrailerClickListener {

    void onTrailerClicked(TrailerRequest trailerRequest);


}